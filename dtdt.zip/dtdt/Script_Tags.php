<?php
include_once('includes/mysql_connect.php');
include_once('includes/shopify.php');

$shopify = new Shopify();
$parameters = $_GET;


include_once('includes/check_token.php');

$script_url = 'https://75145b4a5f46.ngrok.io/dtdt/scripts/dtdt.js';
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    if($_POST['action_type']=='create_script'){
        $scripttag_data=array(
            "script_tag"=>array(
                "event" => "onload",
                "src" => $script_url
            )
        );

        $create_script = $shopify->rest_api('/admin/api/2021-04/script_tags.json',$scripttag_data, 'POST');
        $create_script = json_decode($create_script['body'],true);
        echo print_r($create_script);

    }

}

$scripttags = $shopify->rest_api('/admin/api/2021-04/script_tags.json',array(),'GET');
$scripttags = json_decode($scripttags['body'],true);

echo "<Br/>";
echo "-----------------------------------scripttags--------------------------------------------------";
echo "<Br/>";

echo print_r($scripttags);

?>

<?php include_once('header.php'); ?>

<section>
    <aside>
    <h2>Install Script Tag</h2>    
    </aside>
    <article>
    <div class="card">
        <form action="" method="post">
        <input type="hidden" name="action_type" value="create_script">
        <button type="submit">Create Script Tag</button>
        </form>
    </div></article>
</section>


<?php include_once('footer.php'); ?>