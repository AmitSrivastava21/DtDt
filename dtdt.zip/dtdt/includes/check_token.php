<?php


// Get the shop info
$query = "SELECT * FROM shops where shop_url='" .$parameters['shop'] . "' LIMIT 1";
$result = $mysql->query($query);

// check is shop is alread there
if($result->num_rows < 1)
{
header("Location: install.php?shop=" . $_GET['shop']);
exit();
}

// use fetch assoc to get the records
$store_data = $result->fetch_assoc();
//echo print_r($store_data);

$shopify->set_url($parameters['shop']);
$shopify->set_token($store_data['access_token']);

//echo $shopify->get_url();
//echo "<Br />";
//echo $shopify->get_token();

$shop = $shopify->rest_api('/admin/api/2021-04/shop.json',array(),'GET');
$response = json_decode($shop['body'],true);

if(array_key_exists('errors',$response)){
    echo 'Sorry there is some error in your API call ' . $response['errors'];
   header("Location: install.php?shop=" . $_GET['shop']);
   exit();
}

//echo print_r($response);

?>