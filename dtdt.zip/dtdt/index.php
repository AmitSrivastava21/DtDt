<?php

include_once("includes/mysql_connect.php");
include_once("includes/shopify.php");

$shopify = new Shopify();
$parameters = $_GET;

/************************************************
 * 
 *      Getting Sho Info
 * ************************************************
 */

include_once('includes/check_token.php');
/*****************************
 * 
 * 
*/

//$shop = $shopify->rest_api('/admin/api/2021-04/shop.json',array(),'GET');
//$response = json_decode($shop['body'],true);

?>

<?php include_once('header.php'); ?>



  <section>
  <div class="alert column twelve">
  <dl>
    <dt>
        <p>Welcome to DTDT</p>
    </dt>
  </dl>
</div>
  </section>
  <footer>
   
  </footer>


<?php include_once('footer.php'); ?>