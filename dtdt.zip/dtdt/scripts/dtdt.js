console.log("Thsi is My Script Tag for change    oo oo");

var Ptag1 = document.querySelector('.price-item');

Date.prototype.addDays = function (days) {
    var date = new Date(this.valueOf());
    date.setDate(date.getDate() + days);
    return date;
}

var date = new Date();

console.log(date.addDays(5));

console.log(Ptag1);

var html1 = `
  <article class="dt">
  <Br/>
  <h3> Item will be delivered between ${date} to ${date.addDays(5)} </h3>    
  </article>
  `;
Ptag1.insertAdjacentHTML('beforeend', html1);