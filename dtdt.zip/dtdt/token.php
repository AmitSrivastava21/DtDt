<?php
include_once("includes/mysql_connect.php");

$api_key = '008877280d980a914e2b22ac54262812';
$secret_key = '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';
$parameters = $_GET;
$shop_url = $parameters['shop'];
$hmac = $parameters['hmac'];
$parameters = array_diff_key($parameters,array('hmac'=>''));
ksort($parameters);
$new_hmac=hash_hmac('sha256',http_build_query($parameters),$secret_key);
if(hash_equals($hmac,$new_hmac)){
    
    $var = array(
        "client_id" => $api_key,
        "client_secret" => $secret_key,
        "code" => $parameters['code']
    );
    $access_token_endpoint = 'https://' . $shop_url . '/admin/oauth/access_token';
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $access_token_endpoint);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch,CURLOPT_POST,count($var));
    curl_setopt($ch,CURLOPT_POSTFIELDS,http_build_query($var));
    $response = curl_exec($ch);
    curl_close($ch);
    $response = json_decode($response,true);
   // echo print_r($response);

    $query = "INSERT into shops(shop_url, access_token, install_date) VALUES('" . $shop_url ."','" . $response['access_token'] ."',Now())ON DUPLICATE KEY UPDATE access_token = '" . $response['access_token'] ."'";
    if($mysql->query($query)){
     //  header("Location: https://" . $shop_url . '/admin/apps');
     //  exit();

       echo "<script>top.window.location= 'https://" . $shop_url ."/admin/apps'</script>";
       die;
    }
}
else
{
    echo 'invalid request';
}
?>